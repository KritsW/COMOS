import java.util.*;
public class Mystery {
    public static void main(String[] args) {
        System.out.println("1. This is a line of text");
        System.out.println();

        System.err.println("2. This is a second line of text");
        System.err.println();

        System.out.println("3. This is a third line of text");
    }
}
