import java.io.*;

public class HiddenJavaProgram {
	public static void main(String[] args) {
		System.out.println("Hello, I'm a hidden java program");
	}
}
