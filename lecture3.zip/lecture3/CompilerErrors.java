public class CompilerErrors {
    public static void main(String[] args) {
        System.out.println("Hello World!
        System.out.println("This program won't compile");
    }
}
